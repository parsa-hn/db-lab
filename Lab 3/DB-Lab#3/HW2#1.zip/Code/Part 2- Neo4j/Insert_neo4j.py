import pandas as pd
from py2neo import Graph, Node

USERNAME = "neo4j"
PASS = "neo4j"

graph = Graph("bolt://localhost:7687", auth = (USERNAME, PASS))
graph.delete_all()

def main():
    print("Create Genre Nodes")
    createGenreNodes()

    print("Step 1 out of 3: loading movie nodes")
    loadMovies()

    print("Step 2 out of 3: loading user nodes")
    loadUsers()

    print("Step 3 out of 3: loading rating relationships")
    loadRatings()
#---------------------------------------------
def createGenreNodes():
    allGenres = ["Action", "Adventure", "Animation", "Children's", "Comedy", "Crime",
                 "Documentary", "Drama", "Fantasy", "Film-Noir", "Horror", "Musical",
                 "Mystery", "Romance", "Sci-Fi", "Thriller", "War", "Western"]

    for genre in allGenres:
        gen = Node("Genre", name=genre)
        graph.create(gen)

#----------------------------------------------
def loadMovies():
    readCSV = pd.read_csv('data/movies.dat', sep="::", engine="python", header=None)
    for row in readCSV.itertuples():
        i = row.Index
        createMovieNodes(row)
        createGenreMovieRelationships(row)
        if i%100==0:
            print(f"{i} Movie nodes created")

#-----------------------------------------------
def createMovieNodes(row):
    movieId = row._1
    title = row._2[:-7]
    year = row._2[-5:-1]
    mov = Node("Movie", id=movieId, title=title, year=year)
    graph.create(mov)

#------------------------------------------------
def createGenreMovieRelationships(row):
    movieId = row._1
    movieGenres = row._3.split("|")

    for movieGenre in movieGenres:
        graph.run('MATCH (g:Genre {name: {genre}}), (m:Movie {id: {movieId}}) CREATE (g)-[:IS_GENRE_OF]->(m)',
                  genre=movieGenre, movieId=movieId)

#------------------------------------------------
def loadUsers():
    readCSV = pd.read_csv('data/users.dat', sep="::", engine="python", header=None)
    for row in readCSV.itertuples():
        i = row.Index
        createUserNodes(row)
        if i % 100 == 0:
            print(f"{i} user nodes created")

# -----------------------------------------------
def createUserNodes(row):
    userId = "User "+str(row._1)
    gender = row._2
    age = row._3
    occupation = row._4
    zipcode = row._5
    usr = Node("User", id=userId, gender=gender, age=age, occupation=occupation, zipcode=zipcode)
    graph.create(usr)

# ------------------------------------------------
def loadRatings():
    readCSV = pd.read_csv('data/ratings.dat', sep="::", engine="python", header=None)
    for row in readCSV.itertuples():
        i = row.Index
        createRatingRelationship(row)
        if i%100==0:
            print(f"{i} Rating relationships created")

# ------------------------------------------------
def createRatingRelationship(row):
    ratingData = parseRowRatingRelationships(row)
    graph.run(
        'MATCH (u:User {id: {userId}}), (m:Movie {id: {movieId}}) CREATE (u)-[:RATED { rating: {rating}, timestamp: {timestamp} }]->(m)',
        userId=ratingData[0], movieId=ratingData[1], rating=ratingData[2], timestamp=ratingData[3])

# ------------------------------------------------
def parseRowRatingRelationships(row):
    userId = "User "+str(row._1)
    movieId = row._2
    rating = float(row._3)
    timestamp = row._4
    return (userId, movieId, rating, timestamp)

# ------------------------------------------------

if __name__ == '__main__':
    main()
