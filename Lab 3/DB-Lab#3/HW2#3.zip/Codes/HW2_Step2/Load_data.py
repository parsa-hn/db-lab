# -*- coding: utf-8 -*-
"""
Created on Thu May  7 12:29:50 2020

@author: MrHossein
"""

import csv
from py2neo import Graph, Node

N_MOVIES = 3952
N_RATINGS = 1000209
N_USERS= 6040

USERNAME = "neo4j"
PASS = "bigdata" #default

graph = Graph("bolt://localhost:7687", auth = (USERNAME, PASS))

def main():

    createGenreNodes() 

    print("Step 1 out of 3: loading movie nodes")
    loadMovies()

    print("Step 2 out of 3: loading rating relationships")
    loadRatings()

    print("Step 3 out of 3: Update user nodes data.")
    loadUsers()



def createGenreNodes():
    allGenres = ["Action", "Adventure", "Animation", "Children's", "Comedy", "Crime",
                 "Documentary", "Drama", "Fantasy", "Film-Noir", "Horror", "Musical",
                 "Mystery", "Romance", "Sci-Fi", "Thriller", "War", "Western"]

    for genre in allGenres:
        gen = Node("Genre", name=genre)
        graph.create(gen)



#=============================================================================
#                               Load Movies
#=============================================================================
def loadMovies():
    readDATA = open('data/movies.dat', 'r') 
    i=0
    while True:
        line = readDATA.readline()
        if not line:
            readDATA.close()
            break
        
        line = line[:-1].split('::')
        createMovieNodes(line)
        createGenreMovieRelationships(line)

        if (i % 500 == 0):
            print(f"{i}/{N_MOVIES} Movie nodes created")

        if i >= N_MOVIES:
            readDATA.close()
            break
        
        i += 1

def createMovieNodes(row):
    movieData = parseRowMovie(row)
    id = movieData[0]
    title = movieData[1]
    year = movieData[2]
    mov = Node("Movie", id=id, title=title, year=year)
    graph.create(mov)

def parseRowMovie(row):
    id = row[0]
    year = row[1][-5:-1]
    title = row[1][:-7]

    return (id, title, year)


def createGenreMovieRelationships(row):
    movieId = row[0]
    movieGenres = row[2].split("|")

    for movieGenre in movieGenres:
        graph.run('MATCH (g:Genre {name: $genre}), (m:Movie {id: $movieId}) CREATE (g)-[:IS_GENRE_OF]->(m)',
            genre=movieGenre, movieId=movieId)




#=============================================================================
#                               Load Rating
#=============================================================================
def loadRatings():
    with open('data/ratings.dat') as datafile:
        readDATA = csv.reader(datafile, delimiter=':')
        for i, row in enumerate(readDATA):
            createUserNodes(row)
            createRatingRelationship(row)

            if (i % 10000 == 0):
                print(f"{i}/{N_RATINGS} Rating relationships created")

            if (i >= N_RATINGS):
                break

def createUserNodes(row):
    user = Node("User", id="User " + row[0])
    graph.merge(user, "User", "id")

def createRatingRelationship(row):
    ratingData = parseRowRatingRelationships(row)

    graph.run(
        'MATCH (u:User {id: $userId}), (m:Movie {id: $movieId}) CREATE (u)-[:RATED { rating: $rating, timestamp: $timestamp }]->(m)',
        userId=ratingData[0], movieId=ratingData[1], rating=ratingData[2], timestamp=ratingData[3])

def parseRowRatingRelationships(row):
    userId = "User " + row[0]
    movieId = row[2]
    rating = float(row[4])
    timestamp = row[6]

    return (userId, movieId, rating, timestamp)



#=============================================================================
#                               Load Users
#=============================================================================
def loadUsers():
    with open('data/users.dat') as datafile:
        readDATA = csv.reader(datafile, delimiter=':')
        for i, row in enumerate(readDATA):
            UpdateUserNodesData(row)

            if (i % 500 == 0):
                print(f"{i}/{N_USERS} User Nodes Data Updated")

            if (i >= N_USERS):
                break
            

def UpdateUserNodesData(row):
    userData = parseRowUsersData(row)
    graph.run(
        'MATCH (u:User {id: $userId}) SET u += {userGender: $userGender, userAge: $userAge, UserOccupation: $UserOccupation, userZipcode: $userZipcode}',
        userId=userData[0], userGender=userData[1], userAge=userData[2], UserOccupation=userData[3], userZipcode = userData[4])
    

def parseRowUsersData(row):
    userId = "User " + row[0]
    userGender = row[2]
    userAge = row[4]
    userOccupation = row[6]
    userZipcode = row[8]
    
    return (userId, userGender, userAge, userOccupation, userZipcode)



#=============================================================================
#                               MAIN Function
#=============================================================================
if __name__ == '__main__':
    main()