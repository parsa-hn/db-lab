# -*- coding: utf-8 -*-
"""
Created on Sat May  9 14:05:51 2020

@author: MrHossein
"""

#-----------------------------------------------------------------------------
#                       Neccessary Libraries
#-----------------------------------------------------------------------------
from py2neo import Graph
import time

#-----------------------------------------------------------------------------
#                       Main Function
#-----------------------------------------------------------------------------
if __name__ == '__main__':
    # Connect to Neo4j Database
    USERNAME = "neo4j"
    PASS = "bigdata"
    movieLens_Graph = Graph("bolt://localhost:7687", auth=(USERNAME, PASS))
    
    start_time = time.time()
    # Send Query
    results = movieLens_Graph.run('MATCH (g:Genre)'
                                  'RETURN g.name')
    
    total_time = time.time() - start_time
    
    # Print Results
    print('There are below genres in this database :')
    print('===================================================================')
    index = 1
    for items in results:
        print('{}\t {}'.format(index, items[0]))
        index += 1
    
    print('===================================================================')
    print('Total time for this query : {:.4f} sec'.format(total_time))
    