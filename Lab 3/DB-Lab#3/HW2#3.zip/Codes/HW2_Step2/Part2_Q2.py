# -*- coding: utf-8 -*-
"""
Created on Sat May  9 14:06:47 2020

@author: MrHossein
"""
#-----------------------------------------------------------------------------
#                       Neccessary Libraries
#-----------------------------------------------------------------------------
from py2neo import Graph
import time

#-----------------------------------------------------------------------------
#                       Main Function
#-----------------------------------------------------------------------------
if __name__ == '__main__':
    # Connect to Neo4j Database
    USERNAME = "neo4j"
    PASS = "bigdata"
    movieLens_Graph = Graph("bolt://localhost:7687", auth=(USERNAME, PASS))
    
    start_time = time.time()
    # Send Query
    results = movieLens_Graph.run('MATCH (m:Movie)'
                                  'RETURN count(*)')
    total_time = time.time() - start_time
    
    # Print Results
    print('Total Number of Movies in this database are : {}'.format(results.next()[0])) 
    print('===================================================================')
    print('Total time for this query : {:.4f} sec'.format(total_time))
    