# -*- coding: utf-8 -*-
"""
Created on Sat May  9 14:07:20 2020

@author: MrHossein
"""

#-----------------------------------------------------------------------------
#                       Neccessary Libraries
#-----------------------------------------------------------------------------
from py2neo import Graph
import time

#-----------------------------------------------------------------------------
#                       Main Function
#-----------------------------------------------------------------------------
if __name__ == '__main__':
    # Connect to Neo4j Database
    USERNAME = "neo4j"
    PASS = "bigdata"
    movieLens_Graph = Graph("bolt://localhost:7687", auth=(USERNAME, PASS))
    
    start_time = time.time()
    # Send Query
    results = movieLens_Graph.run('MATCH (g:Genre) - [igf:IS_GENRE_OF] -> (m:Movie) '
                                  'WITH g, count(m) as TotalMovieInEachGenre '
                                  'ORDER BY TotalMovieInEachGenre DESC '
                                  'RETURN TotalMovieInEachGenre as result, g.name LIMIT 1 '
                                  'UNION ALL '
                                  'MATCH (g:Genre) - [igf:IS_GENRE_OF] -> (m:Movie)  <- [r:RATED] - (u:User) '
                                  'WITH g, avg(r.rating) as AvgRatingInEachGenre '
                                  'ORDER BY AvgRatingInEachGenre DESC '
                                  'RETURN AvgRatingInEachGenre as result, g.name LIMIT 1 '
                                  'UNION ALL '
                                  'MATCH (g:Genre) - [igf:IS_GENRE_OF] -> (m:Movie)  <- [r:RATED] - (u:User) '
                                  'WITH g, avg(r.rating) as AvgRatingInEachGenre '
                                  'ORDER BY AvgRatingInEachGenre '
                                  'RETURN AvgRatingInEachGenre as result, g.name LIMIT 1')
                                  
                                  
    total_time = time.time() - start_time
    
    # Print Results
    print('The Result of This Question :')
    print('===================================================================')
    i = 0
    for items in results:
        if i == 0:
            print('The Most Production Movies is in "{}" Genre and The Total Number Movies are: {}'.format(items[1], items[0]))
        elif i == 1:
            print('The Most Movies Rating is in "{}" Genre and Its Average Rating is: {:3f}'.format(items[1], items[0]))
        else:
            print('The Least Movies Rating is in "{}" Genre and Its Average Rating is: {:3f}'.format(items[1], items[0]))
        i += 1
    
    print('===================================================================')
    print('Total time for this query : {:.4f} sec'.format(total_time))
    