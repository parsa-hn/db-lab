# -*- coding: utf-8 -*-
"""
Created on Sat May  9 14:07:08 2020

@author: MrHossein
"""
#-----------------------------------------------------------------------------
#                       Neccessary Libraries
#-----------------------------------------------------------------------------
from py2neo import Graph
import time

#-----------------------------------------------------------------------------
#                       Main Function
#-----------------------------------------------------------------------------
if __name__ == '__main__':
    # Connect to Neo4j Database
    USERNAME = "neo4j"
    PASS = "bigdata"
    movieLens_Graph = Graph("bolt://localhost:7687", auth=(USERNAME, PASS))
    
    start_time = time.time()
    # Send Query
    results = movieLens_Graph.run('MATCH (m:Movie) <- [r:RATED] - (u:User)'
                                  'WITH m, count(r) as TotalrateForEachMovie '
                                  'ORDER BY TotalrateForEachMovie DESC '
                                  'RETURN TotalrateForEachMovie, m.title LIMIT 20')
                                  
                                  
    total_time = time.time() - start_time
    
    # Print Results
    print('Number of Rating for Each Movie in Descending Order :')
    print('===================================================================')
    for items in results:
        print('Number of rating: {}\t Movie name: "{}"'.format(items[0], items[1]))
    
    print('===================================================================')
    print('Total time for this query : {:.4f} sec'.format(total_time))
    