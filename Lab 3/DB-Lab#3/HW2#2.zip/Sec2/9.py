#!/usr/bin/python3

from neo4j import GraphDatabase, basic_auth
driver = GraphDatabase.driver("bolt://localhost:7687", auth=basic_auth("neo4j","a"), encrypted=False)


query = f'''
	MATCH (u:User)-[r:RATED]->(m:Movie)
	WITH DISTINCT(m) as movie, count(r) as count
	WHERE count >= 100
	MATCH (uu:User)-[rr:RATED]->(movie)
	RETURN DISTINCT(movie.title) as title, avg(toFloat(rr.rating)) as average
	ORDER BY average DESC
'''

db = driver.session()
print(query)
results = db.run(query)
limit = 20
for result in results.data()[:limit]:
	print(result['title'])


db.close()
driver.close()