#!/usr/bin/python3

from neo4j import GraphDatabase, basic_auth
driver = GraphDatabase.driver("bolt://localhost:7687", auth=basic_auth("neo4j","a"), encrypted=False)


query = f'''
	MATCH (u:User{{occupation: "12"}})-[r:RATED{{rating: "5"}}]->(m:Movie)
	RETURN DISTINCT(m.title) as movie, count(r) as count
	ORDER BY count DESC
'''

db = driver.session()
print(query)
results = db.run(query)
limit = 10
for result in results.data()[:limit]:
	print(f'{result["movie"]}: {result["count"]}')


db.close()
driver.close()