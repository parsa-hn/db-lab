#!/usr/bin/python3

from neo4j import GraphDatabase, basic_auth
driver = GraphDatabase.driver("bolt://localhost:7687", auth=basic_auth("neo4j","a"), encrypted=False)


query = f'''
	MATCH (m:Movie{{year: "2000"}})
	RETURN m.title
'''

db = driver.session()
print(query)
results = db.run(query)
limit = 20
for result in results.value()[:limit]:
	print(result)


db.close()
driver.close()