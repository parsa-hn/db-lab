#!/usr/bin/python3
#sudo apt-get install openjdk-8-jre
#pip install neo4j==1.7.2
#sed -i 's/::/\t/g' movies.dat
#sed -i 's/::/\t/g' users.dat
#sed -i 's/::/\t/g' ratings.dat

from neo4j import GraphDatabase, basic_auth
driver = GraphDatabase.driver("bolt://localhost:7687", auth=basic_auth("neo4j","a"), encrypted=False)


import_movies_query = f'''
	USING PERIODIC COMMIT 1000
	LOAD CSV FROM "file:///movies.dat" AS csvLine FIELDTERMINATOR '\\t'
	CREATE (m:Movie{{id: csvLine[0], title: substring(csvLine[1], 0, length(csvLine[1])-7), year: left(right(csvLine[1], 5), 4)}})
	WITH csvLine, m
	UNWIND split(csvLine[2], '|') AS genre
	MERGE (g:Genre{{name: genre}})
	CREATE (g)-[r:IS_GENRE_OF]->(m);
'''
import_users_query = f'''
	USING PERIODIC COMMIT 1000
	LOAD CSV FROM "file:///users.dat" AS csvLine FIELDTERMINATOR '\\t'
	CREATE (u:User{{id: csvLine[0], gender: csvLine[1], age:  csvLine[2], occupation: csvLine[3], zipcode: csvLine[4]}});
'''
import_ratings_query = f'''
	USING PERIODIC COMMIT 1000
	LOAD CSV FROM "file:///ratings.dat" AS csvLine FIELDTERMINATOR '\\t'
	MATCH (u:User{{id: csvLine[0]}})
	MATCH (m:Movie{{id: csvLine[1]}})
	CREATE (u)-[r:RATED {{rating: csvLine[2], timestamp: csvLine[3]}}]->(m)
'''

db = driver.session()
print(import_movies_query)
db.run(import_movies_query)
print(import_users_query)
db.run(import_users_query)
print(import_ratings_query)
db.run(import_ratings_query)
db.close()

driver.close()