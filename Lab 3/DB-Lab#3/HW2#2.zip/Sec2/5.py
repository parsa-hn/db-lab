#!/usr/bin/python3

from neo4j import GraphDatabase, basic_auth
driver = GraphDatabase.driver("bolt://localhost:7687", auth=basic_auth("neo4j","a"), encrypted=False)


query = f'''
	MATCH (g:Genre)-[i:IS_GENRE_OF]->(m:Movie)
	RETURN DISTINCT(g.name) as genre, count(i) as count
	ORDER BY count DESC
'''

query2 = f'''
	MATCH (g:Genre)-[i:IS_GENRE_OF]->(m:Movie)<-[r:RATED]-()
	RETURN DISTINCT(g.name) as genre, round(avg(toFloat(r.rating))*100)/100 as average
	ORDER BY average DESC
'''

db = driver.session()
print(query)
results = db.run(query)
for result in results.data():
	print(f'{result["genre"]}: {result["count"]}')

print(query2)
results = db.run(query2)
for result in results.data():
	print(f'{result["genre"]}: {result["average"]}')

db.close()
driver.close()