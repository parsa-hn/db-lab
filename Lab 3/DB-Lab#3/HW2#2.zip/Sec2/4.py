#!/usr/bin/python3

from neo4j import GraphDatabase, basic_auth
driver = GraphDatabase.driver("bolt://localhost:7687", auth=basic_auth("neo4j","a"), encrypted=False)


query = f'''
	MATCH ()-[r:RATED]->(m:Movie)
	RETURN DISTINCT(m.title) as title, count(r) as count
	ORDER BY count DESC
'''

db = driver.session()
print(query)
results = db.run(query)
limit = 10
for result in results.data()[:limit]:
	print(f'{result["title"]}: {result["count"]}')


db.close()
driver.close()