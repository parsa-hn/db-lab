#!/usr/bin/python3

from neo4j import GraphDatabase, basic_auth
driver = GraphDatabase.driver("bolt://localhost:7687", auth=basic_auth("neo4j","a"), encrypted=False)


query = f'''
	MATCH (u:User)-[r:RATED]->(m:Movie)
	WHERE u.age in ["18","25"]
	RETURN DISTINCT(m.title) as movie, avg(toFloat(r.rating)) as average
	ORDER BY average DESC
'''

db = driver.session()
print(query)
results = db.run(query)
limit = 10
for result in results.data()[:limit]:
	print(f'{result["movie"]}: {result["average"]}')


db.close()
driver.close()