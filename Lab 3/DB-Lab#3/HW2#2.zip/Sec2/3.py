#!/usr/bin/python3

from neo4j import GraphDatabase, basic_auth
driver = GraphDatabase.driver("bolt://localhost:7687", auth=basic_auth("neo4j","a"), encrypted=False)


query = f'''
	MATCH ()-[r:RATED]->(m:Movie{{title: "Silence of the Lambs, The"}})
	RETURN r.rating as rating, count(DISTINCT r) as count
'''

db = driver.session()
print(query)
results = db.run(query)
for result in results.data():
	print(f'Rating {result["rating"]}: {result["count"]}')


db.close()
driver.close()