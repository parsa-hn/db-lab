#!/usr/bin/python3

from neo4j import GraphDatabase, basic_auth
driver = GraphDatabase.driver("bolt://localhost:7687", auth=basic_auth("neo4j","a"), encrypted=False)


query = f'''
	MATCH (m:Movie)
	RETURN count(m)
'''

db = driver.session()
print(query)
results = db.run(query)
for result in results.value():
	print(result)


db.close()
driver.close()